package notification

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService

class MyFirebaseInstanceIdService : FirebaseMessagingService() {

    override fun onNewToken(p0: String) {
        Log.d("NEW_TOKEN",p0);

        super.onNewToken(p0)
    }


}