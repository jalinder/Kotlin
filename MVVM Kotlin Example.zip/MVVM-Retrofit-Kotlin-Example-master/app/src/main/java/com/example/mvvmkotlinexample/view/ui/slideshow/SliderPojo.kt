package com.example.mvvmkotlinexample.view.ui.slideshow

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class SliderPojo(
    @SerializedName("title")
    @Expose
    val title: String?,
    @SerializedName("portraitPosterId")
    @Expose
    val portraitPosterId: String?,

    @SerializedName("landscapePosterId")
    @Expose
    val landscapePosterId: String?

    )