package com.example.mvvmkotlinexample.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class ServicesSetterGetter(
   @SerializedName("content")
   @Expose
   val content: List<Content>? = null

//   @SerializedName("pageable")
//   @Expose
//   val pageable: String? = null,
//
//   @SerializedName("last")
//   @Expose
//   val last: Boolean,
//
//   @SerializedName("totalPages")
//   @Expose
//   val totalPages: Int,
//
//   @SerializedName("totalElements")
//   @Expose
//   val totalElements: Int? = null,
//
//   @SerializedName("first")
//   @Expose
//   val first: Boolean,
//
//   @SerializedName("numberOfElements")
//   @Expose
//   val numberOfElements: Int? = null
//@SerializedName("sort")
//@Expose
//private Sort sort;
//@SerializedName("size")
//@Expose
//private Integer size;
//@SerializedName("number")
//@Expose
//private Integer number;

)