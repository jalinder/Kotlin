package com.example.mvvmkotlinexample.view.ui.slideshow

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.mvvmkotlinexample.model.Content
import com.example.mvvmkotlinexample.model.ServicesSetterGetter
import com.example.mvvmkotlinexample.repository.MainActivityRepository

class SlideshowViewModel : ViewModel() {

    var servicesLiveData: MutableLiveData<List<SliderPojo>>? = null

    fun getSlider() : LiveData<List<SliderPojo>>? {
       // servicesLiveData = MainActivityRepository.getSliderApiCall()
        return servicesLiveData
    }
}