package com.example.mvvmkotlinexample.view.ui.slideshow

import com.example.mvvmkotlinexample.model.Content

data class SliderMain (
    val content: List<SliderPojo>? = null

)