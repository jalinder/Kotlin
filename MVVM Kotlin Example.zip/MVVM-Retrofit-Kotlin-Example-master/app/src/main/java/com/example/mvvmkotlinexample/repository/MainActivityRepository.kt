package com.example.mvvmkotlinexample.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.mvvmkotlinexample.model.ServicesSetterGetter
import com.example.mvvmkotlinexample.retrofit.RetrofitClient
import com.example.mvvmkotlinexample.view.ui.slideshow.SliderMain
import com.example.mvvmkotlinexample.view.ui.slideshow.SliderPojo
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object MainActivityRepository {


    val serviceSetterGetter = MutableLiveData<ServicesSetterGetter>()
    val serviceContentGetter = MutableLiveData<List<SliderPojo>?>()
    fun getServicesApiCall(): MutableLiveData<ServicesSetterGetter> {

        val call = RetrofitClient.apiInterface.getServices()

        call.enqueue(object: Callback<ServicesSetterGetter> {
            override fun onFailure(call: Call<ServicesSetterGetter>, t: Throwable) {
                // TODO("Not yet implemented")
                Log.v("DEBUG : ", t.message.toString())
            }

            override fun onResponse(
                call: Call<ServicesSetterGetter>,
                response: Response<ServicesSetterGetter>
            ) {
                // TODO("Not yet implemented")
                Log.v("DEBUG : ", response.body().toString())

                 val data = response.body()

                val msg = data!!.content
//                var arrayList:List<Content>?=null
//
//arrayList.addAll(msg)
                serviceSetterGetter.value = ServicesSetterGetter(msg)
            }
        })

        return serviceSetterGetter
    }
    fun getSliderApiCall(): MutableLiveData<List<SliderPojo>?> {

        val call = RetrofitClient.apiInterface.getSlider()

        call.enqueue(object: Callback<List<SliderPojo>> {
            override fun onFailure(call: Call<List<SliderPojo>>, t: Throwable) {
                // TODO("Not yet implemented")
                Log.v("DEBUG : ", t.message.toString())
            }

            override fun onResponse(
                call: Call<List<SliderPojo>>,
                response: Response<List<SliderPojo>>
            ) {
                // TODO("Not yet implemented")
                Log.v("DEBUG : ", response.body().toString())

                 val data = response.body()


             //   val msg = data!!.title
//                var arrayList:List<Content>?=null
//
//arrayList.addAll(msg)
                serviceContentGetter.value = data
            }
        })

        return serviceContentGetter
    }

}