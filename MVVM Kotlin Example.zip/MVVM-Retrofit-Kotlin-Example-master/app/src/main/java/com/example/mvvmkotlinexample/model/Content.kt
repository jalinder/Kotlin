package com.example.mvvmkotlinexample.model

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




 data class Content(
    @SerializedName("id")
    @Expose
    private val id: String? = null,

    @SerializedName("title")
    @Expose
    public val title: String? = null,

    @SerializedName("titleSlug")
    @Expose
    private val titleSlug: Any? = null,

    @SerializedName("description")
    @Expose
    public val description: String? = null,

    @SerializedName("sortKey")
    @Expose
    private val sortKey: Int? = null,

    @SerializedName("recordStatus")
    @Expose
    private val recordStatus: String? = null,

    @SerializedName("contentId")
    @Expose
    private val contentId: String? = null,

    @SerializedName("posterFileId")
    @Expose
    public val posterFileId: String? = null,

    @SerializedName("internalRating")
    @Expose
    private val internalRating: Int? = null,

    @SerializedName("modifiedAt")
    @Expose
    private val modifiedAt: String? = null,

    @SerializedName("createdAt")
    @Expose
    private val createdAt: String? = null,

    @SerializedName("platform")
    @Expose
    private val platform: kotlin.collections.MutableList<String>? = null,

    @SerializedName("displayType")
    @Expose
    private val displayType: String? = null,

    @SerializedName("externalUrl")
    @Expose
    private val externalUrl: Any? = null)