package com.example.mvvmkotlinexample.view.ui.gallery

import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.mvvmkotlinexample.R
import com.example.mvvmkotlinexample.databinding.FragmentGalleryBinding
import com.example.mvvmkotlinexample.model.User
import com.example.mvvmkotlinexample.viewmodel.UserViewModel

class GalleryFragment : Fragment() {

    private lateinit var mUserViewModel: UserViewModel
    private lateinit var firstName: EditText
    private lateinit var lastName: EditText
    private lateinit var age: EditText
    private lateinit var btnAdd: Button
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_gallery, container, false)

        firstName = view.findViewById(R.id.first_name)
        lastName = view.findViewById(R.id.last_name)
        age = view.findViewById(R.id.age)
        btnAdd = view.findViewById(R.id.btnAdd)

        mUserViewModel = ViewModelProvider(this).get(UserViewModel::class.java)
        btnAdd.setOnClickListener {
            insertDataToDatabase()
        }

        return view
    }

    private fun insertDataToDatabase() {
        val fName = firstName.text.toString()
        val lName = lastName.text.toString()
        val ag = age.text

        if (inputCheck(fName, lName, ag)) {
//            Create User object
            val user = User(0, fName, lName, Integer.parseInt(ag.toString()))
//            Add data to Database
            mUserViewModel.addUser(user)
            Toast.makeText(context, "Successfully added", Toast.LENGTH_LONG).show()
            findNavController().navigate(R.id.action_addFragment_to_listFragment)
        }
    }

    private fun inputCheck(firstName: String, lastName: String, age: Editable): Boolean {
        return !(TextUtils.isEmpty(firstName) && TextUtils.isEmpty(lastName) && age.isEmpty())
    }

}