package com.example.mvvmkotlinexample.retrofit

import com.example.mvvmkotlinexample.model.Content
import com.example.mvvmkotlinexample.model.ServicesSetterGetter
import com.example.mvvmkotlinexample.view.ui.slideshow.SliderPojo
import retrofit2.Call
import retrofit2.http.GET

interface ApiInterface {

    @GET("api/ullu2/media/getActiveUpcomingMedia/cdiOpn?familySafe=no&imageOrientation=LANDSCAPE&platform=ANDROID_PLAY")
    fun getServices() : Call<ServicesSetterGetter>



    @GET("api/ullu2/media/fetchAllMediaSlider/cdiOpn?familySafe=no&platform=ANDROID_PLAY")
    fun getSlider() : Call<List<SliderPojo>>



}