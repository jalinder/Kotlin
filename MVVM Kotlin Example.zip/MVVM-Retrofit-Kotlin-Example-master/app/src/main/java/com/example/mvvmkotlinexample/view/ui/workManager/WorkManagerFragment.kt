package com.example.mvvmkotlinexample.view.ui.workManager

import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.work.Data
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.example.mvvmkotlinexample.R
import com.velmurugan.workmanagerandroid.BlurWorker
import com.velmurugan.workmanagerandroid.DownloadWorker
import com.velmurugan.workmanagerandroid.KEY_IMAGE_URI

class WorkManagerFragment : Fragment() {
    private var downloadedImageUri: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_work_manager, container, false)

        val imageViewNormal = view.findViewById<ImageView>(R.id.imageViewNormal)
        val imageViewBlur = view.findViewById<ImageView>(R.id.imageViewBlur)
        val blurImage = view.findViewById<Button>(R.id.blurImage)
        val downloadImage = view.findViewById<Button>(R.id.downloadImage)

        val oneTimeWorkRequest = OneTimeWorkRequest.Builder(DownloadWorker::class.java).build()
        val blurRequest = OneTimeWorkRequest.Builder(BlurWorker::class.java)

        WorkManager.getInstance(requireContext()).getWorkInfoByIdLiveData(oneTimeWorkRequest.id).observe(this, { workInfo ->
            val imageUri = workInfo?.outputData?.getString(KEY_IMAGE_URI)
            imageUri?.let {
                imageViewNormal.setImageURI(Uri.parse(imageUri))
                downloadedImageUri = it
            }
        })

        downloadImage.setOnClickListener {
            WorkManager.getInstance(requireContext()).enqueue(oneTimeWorkRequest)

            WorkManager.getInstance(requireContext()).
            beginWith(oneTimeWorkRequest)
                .then(blurRequest.build())
                .enqueue()
        }

        blurImage.setOnClickListener {
            val builder = Data.Builder()
            builder.putString(KEY_IMAGE_URI, downloadedImageUri)
            blurRequest.setInputData(builder.build())
            val blurBuilder = blurRequest.build()
            WorkManager.getInstance(requireContext()).getWorkInfoByIdLiveData(blurBuilder.id).observe(requireActivity(), { workInfo2 ->
                val imageUri2 = workInfo2?.outputData?.getString(KEY_IMAGE_URI)
                imageUri2?.let {
                    imageViewBlur.setImageURI(Uri.parse(imageUri2))
                }
            })
            WorkManager.getInstance(requireContext()).enqueue(blurBuilder)
        }


   return view
    }

}