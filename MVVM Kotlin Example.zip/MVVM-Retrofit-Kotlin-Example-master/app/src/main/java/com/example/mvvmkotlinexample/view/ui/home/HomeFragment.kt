package com.example.mvvmkotlinexample.view.ui.home

import adapter.ListAdapter
import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mvvmkotlinexample.R
import com.example.mvvmkotlinexample.databinding.FragmentHomeBinding
import com.example.mvvmkotlinexample.model.User
import com.example.mvvmkotlinexample.viewmodel.UserViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.activity_main.view.*

class HomeFragment:Fragment(), ListAdapter.CallDeleteInterface{

    private lateinit var mUserViewModel: UserViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_home, container, false)

//        RecyclerView
        val adapter = ListAdapter(this)
        val recyclerView = view.recyclerView
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

//        userviewmodel
        mUserViewModel = ViewModelProvider(this).get(UserViewModel::class.java)
        mUserViewModel.readAllData.observe(viewLifecycleOwner, Observer {user->
            adapter.setData(user)
        })



        return view
    }


//    private fun deleteAllUsers() {
//        val builder = AlertDialog.Builder(requireContext())
//        builder.setPositiveButton("Yes"){_,_->
//            mUserViewModel.deleteAllUsers()
//            Toast.makeText(requireContext(),"Deleted all users!", Toast.LENGTH_SHORT).show()
//        }
//        builder.setNegativeButton("No"){_,_-> }
//        builder.setTitle("Delete All?")
//        builder.setMessage("Are you sure you want to delete all users?")
//        builder.create().show()
//    }

    override fun deleteEntity(user: User) {
        deleteSingleUsers(user)
    }

    private fun deleteSingleUsers(user: User) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("Yes"){_,_->
            mUserViewModel.deleteUser(user)
            Toast.makeText(requireContext(),"Deleted all users!", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton("No"){_,_-> }
        builder.setTitle("Delete?")
        builder.setMessage("Are you sure you want to delete this users?")
        builder.create().show()
    }

}