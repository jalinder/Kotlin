package com.example.mvvmkotlinexample.view.ui.slideshow

import com.google.common.annotations.Beta

@Beta
class FinishedMeal (
  public  var burgur:String?=null

)
