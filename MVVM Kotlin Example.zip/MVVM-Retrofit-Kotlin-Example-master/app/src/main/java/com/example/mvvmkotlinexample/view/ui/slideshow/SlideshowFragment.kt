package com.example.mvvmkotlinexample.view.ui.slideshow

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.telephony.gsm.SmsManager.getDefault
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.mvvmkotlinexample.databinding.FragmentSlideshowBinding
import com.google.common.annotations.Beta
import com.google.common.eventbus.EventBus
import com.smarteist.autoimageslider.SliderView
import com.squareup.okhttp.ConnectionPool.getDefault
import eventBus.PublisherViewModel
import kotlinx.android.synthetic.main.fragment_slideshow.*
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import org.greenrobot.eventbus.EventBus.getDefault
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.net.ProxySelector.getDefault
import java.nio.file.FileSystems.getDefault
import java.util.Locale.getDefault
import javax.net.ssl.SSLContext.getDefault

@Beta
class SlideshowFragment : Fragment() {

    private lateinit var slideshowViewModel: SlideshowViewModel
    private lateinit var publisherViewModel: PublisherViewModel
    private var _binding: FragmentSlideshowBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        publisherViewModel =
            ViewModelProvider(this).get(PublisherViewModel::class.java)

        _binding = FragmentSlideshowBinding.inflate(inflater, container, false)
        val root: View = binding.root

//        slideshowViewModel.getSlider()!!.observe(viewLifecycleOwner, Observer {list ->
//
//            var arrayList:ArrayList<SliderPojo>?=null
//            arrayList!!.addAll(list)
//            setImageInSlider(arrayList,slider)
//        })

        publisherViewModel.eventsFlow
            .onEach {
                when (it) {
                    is PublisherViewModel.Event.NavigateToSettings -> {}
                    is PublisherViewModel.Event.ShowSnackBar -> {}
                    is PublisherViewModel.Event.ShowToast -> {}
                }
            }
            .launchIn(viewLifecycleOwner.lifecycleScope)

        binding.save.setOnClickListener(View.OnClickListener { v ->
             val sharedPrefFile = "kotlinsharedpreference"

            val sharedPreferences: SharedPreferences = activity!!.getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)

            val id:Int = Integer.parseInt("inputId.text.toString()")
            val name:String = "inputName.text.toString()"
            val editor: SharedPreferences.Editor =  sharedPreferences.edit()
            editor.putInt("id_key",id)
            editor.putString("name_key",name)
            editor.apply()
            editor.commit()


            val sharedIdValue = sharedPreferences.getInt("id_key",0)
            val sharedNameValue = sharedPreferences.getString("name_key","defaultname")
        binding.txt.text=sharedNameValue+sharedIdValue})
        return root
    }




    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onOrderReady(meal: FinishedMeal) {
        Toast.makeText(
            requireContext(),
            "Meal ready for ticket number: ${meal.burgur} at ${meal.burgur}",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setImageInSlider(images: ArrayList<SliderPojo>, imageSlider: SliderView) {
        val adapter = MySliderImageAdapter()
        adapter.renewItems(images)
        imageSlider.setSliderAdapter(adapter)
        imageSlider.isAutoCycle = true
        imageSlider.startAutoCycle()
    }
}