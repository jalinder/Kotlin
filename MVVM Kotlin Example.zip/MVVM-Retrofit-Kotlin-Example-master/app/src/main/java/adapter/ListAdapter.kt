package adapter

import com.example.mvvmkotlinexample.R
import com.example.mvvmkotlinexample.model.User
import com.example.mvvmkotlinexample.view.ui.gallery.GalleryFragment
import kotlinx.android.synthetic.main.row_item_user.view.*

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView

class ListAdapter(internal var listner: CallDeleteInterface) :
    RecyclerView.Adapter<ListAdapter.MyViewHolder>() {

    private var userList = emptyList<User>()

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.row_item_user, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = userList[position]

        holder.itemView.tv.text = currentItem.id.toString()
        holder.itemView.firstname.text = currentItem.firstName
        holder.itemView.lastname.text = currentItem.lastName
        holder.itemView.age.text = currentItem.age.toString()

        holder.itemView.rowLayout.setOnClickListener {

        }
        holder.itemView.icDelete.setOnClickListener {
            listner.deleteEntity(userList[position])
        }
    }


    fun setData(user: List<User>) {
        this.userList = user
        notifyDataSetChanged()
    }

    open interface CallDeleteInterface {
        fun deleteEntity(user: User)
    }
}