package adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.mvvmkotlinexample.R
import com.example.mvvmkotlinexample.model.Content
import kotlinx.android.synthetic.main.row_item.view.*

class UpcomingAdapter(internal var listner: CallDeleteInterface,internal var context:Context) :
    RecyclerView.Adapter<UpcomingAdapter.MyViewHolder>() {
    var imageBaseUrl = "https://ullu2-files.ullu.app";

    private var userList = emptyList<Content>()

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.row_item, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = userList[position]

        holder.itemView.txtName.text = currentItem.title
        holder.itemView.txtDate.text = currentItem.description
        Glide.with(context)
            .load(imageBaseUrl+currentItem.posterFileId)
            .into(holder.itemView.imageUrl)
    }


    fun setData(user: List<Content>) {
        this.userList = user
        notifyDataSetChanged()
    }

    open interface CallDeleteInterface {
        fun deleteEntity(user: Content)
    }
}