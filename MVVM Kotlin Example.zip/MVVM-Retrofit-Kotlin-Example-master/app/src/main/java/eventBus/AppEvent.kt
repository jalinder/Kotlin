package eventBus

enum class AppEvent {
    LOGOUT;
}